﻿class Program
{
    static void Main()
    {
        Usuario test = new Usuario();
        Console.WriteLine(@"Bienvenido, Que desea hacer?
                            1) Mostrar nombre y notas aprobadas
                            2) Mostrar el promedio de notas 
                            3) Salir");
        int opción = int.Parse(Console.ReadLine());
        switch (opción)
        {
            case 1:
                test.HaAprobado();
                break;
            case 2:
                test.Promedio();
                break;
            case 3:
                Console.ReadLine();
                break;
        }
    }
}
class Usuario
{
    private int[,] Notas = new int[10, 10];
    private string[] Nombre = new string[10];
    public int[,] nota
    {
        get
        {
            return Notas;
        }
    }
    public string[] nombre
    {
        get
        {
            return Nombre;
        }
    }
    // Aquí debería haber un método constructor, pero hacer un método constructor sería inútil en este código ya que el atributo privado de la clase "Usuario", es modificado por el usuario en el método "HaAprobado".
    // Además c# crea un método constructor sin parametros por defecto entonces da lo mismo si escribo uno o no. 
    public void Inicializartabs()
    {
        //Inicializar
        for (int i = 0; i < 10; i++)
        {
            Console.WriteLine("Escribe 10 nombres");
            nombre[i] = Console.ReadLine();
        }
        bool NoCorrecto = true;
        while (NoCorrecto)
        {
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    Console.WriteLine($"escribe la nota de {nombre[i]}");
                    Notas[i, j] = int.Parse(Console.ReadLine());
                    if (Notas[i, j] is int)
                    {
                        NoCorrecto = false;
                    }
                    else
                    {
                        Console.WriteLine("ingresa un número, no otro tipo de dato");
                        NoCorrecto = true;
                    }
                }
            }
        }
    }
    public void HaAprobado()
    {
        Inicializartabs();
        //Printear 
        Console.WriteLine("\n");
        for (int i = 0; i < 10; i++)
        {
            Console.WriteLine($"\tLas notas de {nombre[i]}:");
            for (int j = 0; j < 10; j++)
            {
                if (Notas[i, j] >= 65)
                {
                    Console.Write($"\t{Notas[i, j]}= aprobada");
                }
                else if (Notas[i, j] < 65)
                {
                    Console.Write($"\t{Notas[i, j]}= Reprobada");
                }
            }
            Console.WriteLine("\n");
        }
    }
    public void Promedio()
    {
        Inicializartabs();
        Console.WriteLine("\nPromedio de notas por estudiante");
        for (int i = 0; i < 10; i++)
        {
            int suma = 0;
            for (int j = 0; j < 10; j++)
            {
                suma += Notas[i, j];
            }
            double promedio = (double)suma / 10; 
            Console.WriteLine($"{nombre[i]} tiene un promedio de: {promedio:F2}");
        }
    }
}


