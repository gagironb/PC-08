﻿class program
{
    void DisplayWeatherReport(double temCelsius)
    {
        if (temCelsius < 2)
        {
            Console.WriteLine("Cold");
        }
        else
        {
            Console.Write("Perfect");
        }
    }
    void DisplayCharInfo(char ch)
    {
        if (char.IsLower(ch))
        {
            Console.WriteLine($"Lowercase letter: {ch}");
        }
        else if (char.IsDigit(ch))
        {
            Console.WriteLine($"A digit: {ch}")
        }
        else {
            Console.WriteLine($"not alphanumeric caracter: {ch}");
        }
    }
}