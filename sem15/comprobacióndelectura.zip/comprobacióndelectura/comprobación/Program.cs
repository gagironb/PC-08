﻿using System.Dynamic;
using System.Reflection.Metadata;
using System.Security.Cryptography.X509Certificates;

class Estudiante { 
        string Nombre;
        string Carrera;
        int Carnet;
        int notaAdmision;
        int Edad;
        public static void Main(){
            //Ciclo principal
            bool ciclo = true;
            while (ciclo == true){
                //instancia de variables
                Estudiante estudiante = new Estudiante();
                Console.WriteLine("Ingresa tu nombre");
                estudiante.Nombre = Console.ReadLine();
                Console.WriteLine("Ingresa tu Carrera");
                estudiante.Carrera = Console.ReadLine();
                Console.WriteLine("Ingresa tu Carnet (Solo números y con terminación en 2025)");
                estudiante.Carnet = int.Parse(Console.ReadLine());
                Console.WriteLine("Ingresa tu Nota(mayor a 75)");
                estudiante.notaAdmision = int.Parse(Console.ReadLine());
                Console.WriteLine("Ingresa tu Edad");
                estudiante.Edad = int.Parse(Console.ReadLine());
                //comprobacionescorrectas
                var Matricula = estudiante.ComproMatricular();
                
                // cerrar ciclo
                if (Matricula == true){
                    //RESUMEN
                    Console.WriteLine(@$"Resumen de datos:
                                            1)Nombre = {estudiante.Nombre}
                                            2)Carrera = {estudiante.Carrera}
                                            3)Carné = {estudiante.Carnet}
                                            4)Nota = {estudiante.notaAdmision}
                                            5)Edad = {estudiante.Edad}
                                            Usted puede matricularse en la URL: {Matricula}");
                                            break;
                }
                else{
                    Console.WriteLine("Escribió algo mal. Por favor, vuelva a escribir los datos");
                }
            }
        }
        public bool ComproMatricular(){
            return notaAdmision > 75 && Carnet.ToString().EndsWith("2025");
        }

    }



